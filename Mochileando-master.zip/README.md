# Mochileando

Mochileando es una aplicación que ofrece servicio de planeamiento de rutas de viaje, a través de recomendaciones hechas por los mismos usuarios de la aplicación.
