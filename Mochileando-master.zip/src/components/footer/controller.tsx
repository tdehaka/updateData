import React from "react";

import View from "./view";

export default () => {
  return <View />;
};
