import React from "react";

export default () => {
  return (
    <div className="rounded overflow-hidden shadow-lg m-5">
      <div className="px-6 py-4">
        <div className="font-bold text-xl mb-2">Footer</div>
      </div>
    </div>
  );
};
