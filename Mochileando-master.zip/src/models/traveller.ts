interface traveller {
  nombre: string;
  email: string;
  contraseña: string;
}

export default traveller;
