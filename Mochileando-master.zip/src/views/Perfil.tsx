import React, {
    ReactElement,
    useRef,
    useContext,
    useEffect,
    useState,
} from "react";
import { app } from "../firebaseConfig";

import Header from "../components/Header";
import { useHistory } from "react-router-dom";
import { Auth } from "../context/AuthContext";

export default function Perfil(): ReactElement {
    let history = useHistory();
    const { usuario } = useContext(Auth);
    const [error, seterror] = useState("");
    const date = new Date(Date.now()).getFullYear()

    useEffect(() => {
        if (usuario) {
            history.push("/perfil");
        }
    }, [history, usuario]);

    return(
        <div className="grid-home-page-traveller-container bg-gray-900" style={{ height: window.innerHeight }}>
            <div className="grid-side-bar">
                <Header history={history} state="authorized" height={window.innerHeight} />
            </div>
        </div>
    );
}